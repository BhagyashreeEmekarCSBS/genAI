# Marketing + Finance Multi-Agent Application

An autonomous multi-agent negotiation system where a **Marketing Agent** generates promotional strategies and a **Finance Agent** audits the budget. If the strategy exceeds the budget, the Finance Agent sends constructive feedback, prompting the Marketing Agent to dynamically revise and optimize the plan until approved.

---

## Project Structure

- `marketing_finance_agents.py` - Core multi-agent logic (MarketingAgent, FinanceAgent, orchestrator).
- `web_app.py` - Flask web server hosting the interactive localhost dashboard.
- `templates/index.html` - Responsive single-page web UI.
- `.env` - Environment configuration containing your `GEMINI_API_KEY`.
- `requirements.txt` - Project dependencies.

---

## Setup & Running

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure API Key
Create or edit `.env` in the project root:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```

### 3. Run Web Dashboard (Localhost)
```bash
python web_app.py
```
Open your browser at **http://localhost:5000**.

### 4. Run CLI Version (Terminal)
```bash
python marketing_finance_agents.py
```
