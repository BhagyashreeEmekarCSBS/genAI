"""
Marketing + Finance Multi-Agent Web Application
------------------------------------------------
Serves a modern interactive web UI on localhost (127.0.0.1:5000)
Runs the Marketing Agent & Finance Agent negotiation loop with real-time visual feedback.
"""

import os
import sys
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv()
load_dotenv(os.path.expanduser("~/.env"))

from flask import Flask, render_template, request, jsonify
from marketing_finance_agents import run_campaign

app = Flask(__name__)


@app.route("/")
def index():
    """Serve the main dashboard UI."""
    return render_template("index.html")


@app.route("/api/run-agents", methods=["POST"])
def run_agents():
    """API endpoint to run the multi-agent negotiation loop."""
    try:
        data = request.get_json(force=True) or {}
        product = data.get("product", "Eco-friendly water bottle").strip()
        audience = data.get("audience", "College students").strip()
        budget = float(data.get("budget", 50000))
        max_rounds = int(data.get("max_rounds", 3))

        if not product or not audience or budget <= 0:
            return jsonify({"error": "Invalid input parameters. Please check product, audience, and budget."}), 400

        result = run_campaign(
            product=product,
            audience=audience,
            budget=budget,
            max_rounds=max_rounds,
        )

        return jsonify(result)

    except Exception as e:
        print(f"[Error in /api/run-agents]: {e}", file=sys.stderr)
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"\n=======================================================")
    print(f"🚀 Multi-Agent Web Dashboard running on http://127.0.0.1:{port}")
    print(f"=======================================================\n")
    app.run(host="127.0.0.1", port=port, debug=False)
