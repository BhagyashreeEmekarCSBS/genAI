"""
Marketing + Finance Multi-Agent Application
-------------------------------------------
Marketing Agent -> generates a promotional strategy (with cost per activity)
Finance Agent   -> checks whether the strategy fits the given budget
If it does not fit, Finance sends feedback and Marketing revises the plan.

Setup (in terminal):
    pip install google-genai
    # Windows PowerShell:
    $env:GEMINI_API_KEY="your_api_key_here"
    # Windows CMD:
    set GEMINI_API_KEY=your_api_key_here
Run:
    python marketing_finance_agents.py
    # or with uv:
    uv run --with google-genai python marketing_finance_agents.py
"""

import os
import sys
import json
import re

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# Load environment variables from .env if present
try:
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv(os.path.expanduser("~/.env"))
except ImportError:
    pass

from google import genai
from google.genai import types

# Validate API key presence
api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
if not api_key:
    print("\n[Error] GEMINI_API_KEY environment variable is not set.", file=sys.stderr)
    print("Please set your Gemini API key in .env or run the setup command:", file=sys.stderr)
    print("  PowerShell: $env:GEMINI_API_KEY=\"your_key\"", file=sys.stderr)
    print("  CMD:        set GEMINI_API_KEY=your_key", file=sys.stderr)
    print("  Bash:       export GEMINI_API_KEY=\"your_key\"\n", file=sys.stderr)
    sys.exit(1)

client = genai.Client(api_key=api_key)
# Fast, stable model with automatic fallback
DEFAULT_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash")
FALLBACK_MODELS = [DEFAULT_MODEL, "gemini-3.5-flash", "gemini-3.5-flash-lite", "gemini-3.8-flash"]
# Remove duplicates while preserving order
CANDIDATE_MODELS = list(dict.fromkeys(FALLBACK_MODELS))


def ask_llm(prompt: str, json_mode: bool = False) -> str:
    """Send a prompt to Gemini and return the text reply with automatic model fallback."""
    config = None
    if json_mode:
        config = types.GenerateContentConfig(response_mime_type="application/json")

    last_error = None
    for model_name in CANDIDATE_MODELS:
        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=config,
            )
            return response.text.strip() if response.text else ""
        except Exception as err:
            last_error = err
            continue

    if last_error:
        raise last_error
    return ""


def parse_json(text: str) -> dict:
    """Safely extract and parse JSON even if surrounded by markdown fences or commentary."""
    text = text.strip()
    # Strip markdown code blocks if present
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"\s*```$", "", text)
        text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Fallback: search for outermost JSON object {...}
        match = re.search(r"(\{.*\})", text, re.DOTALL)
        if match:
            return json.loads(match.group(1))
        raise


# ---------------------------------------------------------------- Marketing Agent
class MarketingAgent:
    name = "Marketing Agent"

    def create_strategy(self, product: str, audience: str, budget: float,
                        feedback: str = "") -> dict:
        prompt = f"""
You are a Marketing Agent. Create a promotional strategy.

Product: {product}
Target audience: {audience}
Approximate budget: {budget}
{"Finance feedback to fix: " + feedback if feedback else ""}

Return ONLY valid JSON in this format (no extra text):
{{
  "campaign_name": "string",
  "summary": "string",
  "activities": [
    {{"channel": "string", "description": "string", "cost": number}}
  ]
}}
"""
        return parse_json(ask_llm(prompt, json_mode=True))


# ---------------------------------------------------------------- Finance Agent
class FinanceAgent:
    name = "Finance Agent"

    def review(self, strategy: dict, budget: float) -> dict:
        # Exact calculation done in code (reliable)
        total = sum(a["cost"] for a in strategy["activities"])
        within_budget = total <= budget

        # LLM gives a short financial opinion / suggestion
        prompt = f"""
You are a Finance Agent. Budget = {budget}. Total plan cost = {total}.
Plan: {json.dumps(strategy)}
In 2 short sentences, say whether the plan is financially acceptable and,
if it is over budget, which activities to cut or reduce.
"""
        comment = ask_llm(prompt)

        return {
            "total_cost": total,
            "budget": budget,
            "approved": within_budget,
            "difference": round(budget - total, 2),
            "comment": comment,
        }


# ---------------------------------------------------------------- Orchestrator
def run_campaign(product: str, audience: str, budget: float, max_rounds: int = 3) -> dict:
    """Execute the multi-agent negotiation loop and return full structured history."""
    marketing = MarketingAgent()
    finance = FinanceAgent()
    feedback = ""
    rounds_history = []

    final_strategy = None
    final_result = None
    approved = False

    for round_no in range(1, max_rounds + 1):
        strategy = marketing.create_strategy(product, audience, budget, feedback)
        result = finance.review(strategy, budget)

        round_data = {
            "round": round_no,
            "strategy": strategy,
            "result": result,
            "feedback_applied": feedback if round_no > 1 else ""
        }
        rounds_history.append(round_data)

        final_strategy = strategy
        final_result = result

        if result["approved"]:
            approved = True
            break

        feedback = (f"Plan cost {result['total_cost']} exceeds budget {budget}. "
                    f"{result['comment']}")

    return {
        "product": product,
        "audience": audience,
        "budget": budget,
        "approved": approved,
        "rounds_count": len(rounds_history),
        "rounds": rounds_history,
        "final_strategy": final_strategy,
        "final_result": final_result
    }


def run(product: str, audience: str, budget: float, max_rounds: int = 3):
    """CLI orchestrator for running and printing agent negotiation."""
    data = run_campaign(product, audience, budget, max_rounds=max_rounds)

    for item in data["rounds"]:
        r_num = item["round"]
        strat = item["strategy"]
        res = item["result"]

        print(f"\n===== ROUND {r_num} =====")
        print(f"[Marketing Agent] Campaign: {strat.get('campaign_name', 'N/A')}")
        print(f"Summary: {strat.get('summary', 'N/A')}")
        for a in strat.get("activities", []):
            print(f"  - {a.get('channel', 'Channel')}: {a.get('description', '')}  (Cost: {a.get('cost', 0)})")

        print(f"\n[Finance Agent] Total cost: {res['total_cost']} | Budget: {res['budget']}")
        print(f"Comment: {res['comment']}")

        if res["approved"]:
            try:
                print("\n✅ APPROVED - Strategy fits the budget.")
            except UnicodeEncodeError:
                print("\n[APPROVED] - Strategy fits the budget.")
        else:
            try:
                print("\n❌ REJECTED - Over budget. Sending feedback to Marketing Agent...")
            except UnicodeEncodeError:
                print("\n[REJECTED] - Over budget. Sending feedback to Marketing Agent...")

    if not data["approved"]:
        try:
            print("\n⚠ Could not fit the budget within the allowed rounds.")
        except UnicodeEncodeError:
            print("\n[WARNING] - Could not fit the budget within the allowed rounds.")

    return data["final_strategy"], data["final_result"]


if __name__ == "__main__":
    product = input("Enter product: ") or "Eco-friendly water bottle"
    audience = input("Enter target audience: ") or "College students"
    budget = float(input("Enter budget: ") or 50000)
    run(product, audience, budget)
